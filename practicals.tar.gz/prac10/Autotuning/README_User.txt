AUTOTUNING SYSTEM

VERSION 0.16



These two should provide an introduction to the tuner:
docs/user.pdf
docs/tutorial.pdf

All the actual code is in tuner/, the main program is tuner/tune.py.
There are a few examples to show you how the system works in examples/.

If you run tuner/tune.py with no arguments, it will run a short demonstration.

'autotune' in the top level directory is a link to tune.py



The tuner is written in python and requires at least version 2.5.
